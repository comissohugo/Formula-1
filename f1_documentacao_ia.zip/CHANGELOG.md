# F1 DATA CENTER --- Changelog

Registro cronológico das decisões, entregas e alterações do projeto.

## 2026-11-08 --- Início da documentação central

### Decisões confirmadas pelo usuário

-   Formato escolhido: dashboard interativo.
-   Nível de detalhamento: completo.
-   Temporadas iniciais: 2021, 2022, 2023, 2024 e 2025.
-   Temporada 2026: adicionar somente após o encerramento.
-   Detalhamento por GP: classificação e corrida completas.
-   O usuário quer poder compartilhar este documento Markdown com outra
    IA para continuar o projeto.

### Escopo confirmado

-   Classificação: posições, pilotos, equipes e tempos Q1/Q2/Q3 quando
    disponíveis.
-   Corrida: classificação completa, grid, voltas, pontos, status, tempo
    e volta mais rápida quando disponível.
-   Rankings e comparações de pilotos e equipes.
-   Sprint em seção separada, sem misturar com GP principal.

### Protótipo preparado

Foi criado o pacote `f1_data_center_2021_2025.zip`, contendo: -
`app.py` - `requirements.txt` - `README.md`

Tecnologias do protótipo: Python, Streamlit, Pandas, Requests e Plotly.
Fonte planejada: Jolpica F1 API.

### Estado técnico no fechamento desta entrada

-   O pacote do protótipo foi gerado.
-   O usuário informou que já tem Python instalado.
-   A instalação das dependências e a execução local ainda não foram
    concluídas.
-   A importação efetiva dos dados 2021--2025 ainda não foi executada
    nem validada.
-   O código inicial precisa ser testado, especialmente a paginação dos
    endpoints e a conferência dos dados históricos.
-   Não afirmar que os 114 GPs já foram importados.

### Próxima ação

Ajudar o usuário no Windows a extrair o ZIP, instalar dependências com:

``` bash
python -m pip install -r requirements.txt
```

e iniciar o painel com:

``` bash
streamlit run app.py
```

Depois, corrigir eventuais erros e implementar importação persistente e
validação da base.

------------------------------------------------------------------------

## Modelo para próximas atualizações

### AAAA-MM-DD --- Título da alteração

-   **Decisão:**
-   **Arquivos alterados:**
-   **O que foi implementado:**
-   **Testes realizados:**
-   **Problemas conhecidos:**
-   **Próxima ação:**
